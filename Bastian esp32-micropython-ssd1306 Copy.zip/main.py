{
  "version": 1,
  "parts": [
    // Papan ESP32
    { "type": "board-esp32-devkit-v1" },
    
    // Layar OLED I2C (SSD1306)
    {
      "type": "ssd1306",
      "id": "oled1",
      "attrs": { "width": 128, "height": 64, "address": "0x3C" },
      "pincs": [
        { "id": "21", "signal": "SDA" }, 
        { "id": "22", "signal": "SCL" }
      ]
    },
    
    // Tombol Naik (Warna Hijau)
    {
      "type": "wokwi-pushbutton",
      "id": "btn_up",
      "attrs": { "color": "green", "label": "NAIK" },
      "pincs": [
        { "id": "13", "target": "board:13", "signal": "GND" } 
      ]
    },
    
    // Tombol Turun (Warna Merah)
    {
      "type": "wokwi-pushbutton",
      "id": "btn_down",
      "attrs": { "color": "red", "label": "TURUN" },
      "pincs": [
        { "id": "12", "target": "board:12", "signal": "GND" }
      ]
    }
  ]
}